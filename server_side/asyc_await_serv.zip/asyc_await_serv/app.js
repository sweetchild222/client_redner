const express = require('express');
const app = express()

const sleep_span = 500

function sleep(ms) {
	return new Promise((resolve) => {
		setTimeout(resolve, ms);
	});
}

app.get('/a', async function (req, res) {
	await sleep(sleep_span)
	res.send('SAMSUNG')
})


app.get('/b', async function (req, res) {
	await sleep(sleep_span)
	res.send('SW')

})


app.get('/c', async function (req, res) {
	await sleep(sleep_span)
	res.send('ACADEMY')
})


app.get('/d', async function (req, res) {
	await sleep(sleep_span)
	res.send('FOR')
})


app.get('/e', async function (req, res) {
	await sleep(sleep_span)
	res.send('YOUTH')
})


app.use(function(req, res, next) {
	res.status(404).send('page not found');
});


const port = 8842

app.listen(port, function () {
	  console.log('listening on port ' + port);
})
